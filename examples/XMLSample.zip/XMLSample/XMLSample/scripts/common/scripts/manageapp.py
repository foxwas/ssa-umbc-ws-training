#COPYRIGHT LICENSE:  This information contains sample code provided in source
#code form. You may copy, modify, and distribute these sample programs in any
#form without payment to IBM for the purposes of developing, using, marketing
#or distributing application programs conforming to the application programming
#interface for the operating platform for which the sample code is written.
#Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
#ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
#INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
#MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
#AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
#ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
#OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
#PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
#SAMPLE SOURCE CODE.

import sys

# Save WAS admin configuration
def saveConfig():
	try:
		AdminConfig.save()
	except:
		print 'Unable to save configuration. %s' % sys.exc_info()[1]


# Add (install) a BLA or an enterprise application
def addBLA(name, assetSource, assetName, compositeName):
	def createBLA(name):
		AdminTask.createEmptyBLA('-name ' + name)

	def importAsset(source):
		if len(source.strip()) > 0:
			AdminTask.importAsset('-source %s -storageType FULL' % source)

	def addCompositToBLA(blaName, assetName, compositeName):
		if len(assetName.strip()) <= 0:
			return

		options = '-blaID %s -cuSourceID %s' % (blaName, assetName)

		if len(compositeName.strip()) > 0:
			options = '%s -deplUnits "%s"' % (options, compositeName)

		AdminTask.addCompUnit(options)

	try:
		createBLA(name)
	except:
		print 'Unable to create empty BLA %s. %s' % (name, sys.exc_info()[1])

	try:
		importAsset(assetSource)
	except:
		print 'Unable to import asset %s. %s' % (assetSource, sys.exc_info()[1])

	try:
		addCompositToBLA(name, assetName, compositeName)
	except:
		print 'Unable to add composite %s in asset %s to BLA %s. %s' % (compositeName, assetName, name, sys.exc_info()[1])

        
# Add (install) a BLA for the HelloJee Sample with Jee implementation
def addJeeSampleBLA(baseDir):

	def importAsset(source):
		try:
			print 'Importing asset %s. ' % source
			if len(source.strip()) > 0:
				AdminTask.importAsset('-source %s -storageType FULL' % source)
		except:
			print 'Unable to import asset %s. %s' % (source, sys.exc_info()[1])

	def addjeeArchCompositToBLA(blaName, jeeName):
		try:
			print 'Adding jee archive %s to BLA %s' % (jeeName, blaName)
			if len(jeeName.strip()) <= 0:
				return

			options = '-blaID %s -cuSourceID %s' % (blaName, jeeName)

			AdminTask.addCompUnit(options)
		except:
			print 'Unable to Adding jee archive %s to BLA %s. %s' % (jeeName, blaName, sys.exc_info()[1])



	blaName = "HelloJeeBla"
	scaName = "HelloJeeSca.jar"
	scaSource = baseDir + scaName
	jeeApp = "HelloJeeEar"
	jeeName = jeeApp + ".ear"
	jeeSource = baseDir + jeeName
	jeeComponent = "HelloJeeComponent"
	jeeEnhancedApp = "HelloJeeEnhancedEar"
	jeeEnhancedName = jeeEnhancedApp + ".ear"
	jeeEnhancedSource = baseDir + jeeEnhancedName
	jeeEnhancedComponent = "HelloJeeEnhancedComponent"
	
	try:
		print 'Creating empty BLA %s' % blaName
		AdminTask.createEmptyBLA('-name ' + blaName)
	except:
		print 'Unable to create empty BLA %s. %s' % (name, sys.exc_info()[1])

	importAsset(scaSource)
	importAsset(jeeSource)
	importAsset(jeeEnhancedSource)

	addjeeArchCompositToBLA(blaName, jeeName)
	addjeeArchCompositToBLA(blaName, jeeEnhancedName)
    
	try:
		options = '-blaID %s -cuSourceID %s -JeeImplementation [[ %s %s %s][ %s %s %s]]' % (blaName, scaName, jeeComponent, jeeName, jeeApp, jeeEnhancedComponent, jeeEnhancedName, jeeEnhancedApp)
		print 'Adding jee composite to BLA with options: %s' % options

		AdminTask.addCompUnit(options)
	except:
		print 'Unable to add composite to BLA  %s' % (sys.exc_info()[1])


        
        
        
        
def addEnterpriseApp (source, options):

    try:
		AdminApp.install(source, '[%s]' % options)
    except:
		print 'Unable to add enterprise application %s. %s' % (source, sys.exc_info()[1])


# Remove (uninstall) a BLA or an enterprise application
def removeBLA(name, asset):
	def removeCompUnits(blaName):
		rawCompUnits = AdminTask.listCompUnits('-blaID blaname=%s' % blaName)

		# Parse and pretty output
		rawCompUnitsList = rawCompUnits.splitlines()
		compUnits = [x.strip() for x in rawCompUnitsList if x.startswith('WebSphere:cuname=')]

		for compUnit in compUnits:
			AdminTask.deleteCompUnit('-blaID %s -cuID "%s" -force true' % (blaName, compUnit))

	def removeAsset(asset):
		AdminTask.deleteAsset('-assetID %s' % asset)

	def removeBLASimple(name):
		AdminTask.deleteBLA('-blaID %s' % name)


	try:
		if name != '':
			removeCompUnits(name)
	except:
		print 'Unable to remove composition units for BLA %s. %s' % (name, sys.exc_info()[1])

	try:
		if asset != '':
			removeAsset(asset)
	except:
		print 'Unable to remove asset %s for BLA %s. %s' % (asset, name, sys.exc_info()[1])

	try:
		if name != '':
			removeBLASimple(name)
	except:
		print 'Unable to remove BLA %s. %s' % (name, sys.exc_info()[1])

# Remove (uninstall) a BLA for the HelloJee Sample with Jee implementation
def removeJeeSampleBLA():
	def removeCompUnits(blaName):
		rawCompUnits = AdminTask.listCompUnits('-blaID blaname=%s' % blaName)

		# Parse and pretty output
		rawCompUnitsList = rawCompUnits.splitlines()
		compUnits = [x.strip() for x in rawCompUnitsList if x.startswith('WebSphere:cuname=')]

		for compUnit in compUnits:
			AdminTask.deleteCompUnit('-blaID %s -cuID "%s" -force true' % (blaName, compUnit))

	def removeAsset(asset):
		AdminTask.deleteAsset('-assetID %s' % asset)

	def removeBLASimple(name):
		AdminTask.deleteBLA('-blaID %s' % name)


	blaName = "HelloJeeBla"
	scaName = "HelloJeeSca.jar"
	jeeName = "HelloJeeEar.ear"
	jeeEnhancedName = "HelloJeeEnhancedEar.ear"


	try:
		removeCompUnits(blaName)
	except:
		print 'Unable to remove composition units for BLA %s. %s' % (blaName, sys.exc_info()[1])

	try:
		removeAsset(scaName)
		removeAsset(jeeName)
		removeAsset(jeeEnhancedName)
	except:
		print 'Unable to remove assets.'

	try:
		removeBLASimple(blaName)
	except:
		print 'Unable to remove BLA %s. %s' % (blaName, sys.exc_info()[1])







def removeEnterpriseApp(name):

    try:
		AdminApp.uninstall(name)
    except:
		print 'Unable to remove enterprise application %s. %s' % (name, sys.exc_info()[1])


# Start a BLA or an enterprise application
def startBLA(name):
	try:
		AdminTask.startBLA(['-blaID', name])
	except:
		print 'Unable to start BLA %s. %s' % (name, sys.exc_info()[1])

def startEnterpriseApp(name):
	cell = AdminControl.getCell()
	node = AdminControl.getNode()

	try:
		appManager = AdminControl.queryNames('cell=%s,node=%s,type=ApplicationManager,*' % (cell, node))

		AdminControl.invoke(appManager, 'startApplication', name)
	except:
		print 'Unable to start enterprise application %s. %s' % (name, sys.exc_info()[1])


# Stop a BLA or an enterprise application
def stopBLA(name):
	try:
		AdminTask.stopBLA(['-blaID', name])
	except:
		print 'Unable to stop BLA %s. %s' % (name, sys.exc_info()[1])

def stopEnterpriseApp(name):
	cell = AdminControl.getCell()
	node = AdminControl.getNode()

	try:
		appManager = AdminControl.queryNames('cell=%s,node=%s,type=ApplicationManager,*' % (cell, node))

		AdminControl.invoke(appManager, 'stopApplication', name)
	except:
		print 'Unable to stop enterprise application %s. %s' % (name, sys.exc_info()[1])


def removeResourcesByUuid(resourceType, uuid):
	resourcesRaw = AdminConfig.list(resourceType)
	resourcesRawList = resourcesRaw.splitlines()
	resources = [x for x in resourcesRawList if x.find(uuid) != -1]

	for x in resources:
		AdminConfig.remove(x)

def setApplicationSecurity(isEnabled):
	if isEnabled:
		action = 'enable'
		value = 'true'
	else:
		action = 'disable'
		value = 'false'
	
	try:
		AdminTask.setAdminActiveSecuritySettings(['-appSecurityEnabled', value])
	except:
		print "Cannot %s application security. %s" % (action, sys.exc_info()[1])
	