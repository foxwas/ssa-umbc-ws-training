/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import java.io.*;

public class Escaping {
	/**
	 * This class escapes an XML String into a form that can be embedded into HTML.  It is likely
	 * that more should be added to the escaped characters, but this is sufficient for the samples.
	 */
	public static String fixXMLForHTML(String input) {
		StringWriter writer = new StringWriter();
		for (int ii = 0; ii < input.length(); ii++) {
			char c = input.charAt(ii);
			if (c == '<') {
				writer.write("&lt;");
			}
			else if (c == '>') {
				writer.write("&gt;");
				
			}
			else if (c == '"') {
				writer.write("&quot;");
			}
			else if (c == '&') {
				writer.write("&amp;");
			}
			else {
				writer.write(c);
			}
		}
		return writer.toString();
	}
}
