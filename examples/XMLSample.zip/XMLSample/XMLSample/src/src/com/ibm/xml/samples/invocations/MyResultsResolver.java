/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import com.ibm.xml.xapi.*;

import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import java.io.*;

/**
 * A fairly simple instance of a XResultsResolver that redirects the
 * output to byte arrays that are eventually fetched by the calling
 * program after the XSLT completes
 */
public class MyResultsResolver implements XResultResolver {
	private ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
	private ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
	
	private StreamResult result1;
	private StreamResult result2;
	
	public MyResultsResolver() {
		result1 = new StreamResult(baos1);
		result2 = new StreamResult(baos2);
	}
	
    public Result getResult(String href, String base) {
    	// This string matches one href in the multipleresults.xslt result-document instructions
    	if (href.equals("doc1")) {
    		return result1;
    	}
    	// This string matches the other href in the multipleresults.xslt result-document instructions
    	else if (href.equals("doc2")) {
    		return result2;
    	}
    	else {
    		throw new RuntimeException("invalid href");
    	}
    }
    
    public String getResult1() {
    	return baos1.toString();
    }
    
    public String getResult2() {
    	return baos2.toString();
    }
}
