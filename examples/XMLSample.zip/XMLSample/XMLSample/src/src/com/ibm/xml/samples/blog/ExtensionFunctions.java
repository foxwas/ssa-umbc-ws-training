/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.blog;

public class ExtensionFunctions {
	private static String LEGACY_KEYWORD = "KEYWORD";
	
	public static Boolean legacyContentAnalysis(String input) {
		// Consider this function to be a function that exists in Java today that we don't have time or
		// resource to rewrite in XPath or XSLT.  Therefore, we want to easily add this function to
		// our XPath using extension functions.  Obviously, this function is something that could be
		// implemented in XPath, but its for example only.  In reality this function would likely contain
		// extensive Java logic and/or connections to datasources not contained in the incoming XML.
		
		int index = input.indexOf(LEGACY_KEYWORD);
		return new Boolean(index != -1);
	}
}
