/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.jdbcresolvers;

import com.ibm.xml.xapi.*;
import java.sql.*;
import java.util.*;

import javax.xml.transform.stream.StreamSource;

public class JDBCCollectionResolver implements XCollectionResolver {
	private static String URI_SCHEME = "jdbc://";
	
	private Connection dbConnection;
	private HashMap<String, String> namesToStatementStrings;
	private boolean treatClobAsXML = false;

	/**
	 * Create a collection resolver that can resolve named statements with parameterized values
	 * to JDBC query statements.
	 * @param con Any JDBC connection
	 * @param statements A collection of named statements to queries
	 * @throws Exception 
	 */
	public JDBCCollectionResolver(Connection con, HashMap<String, String> statements) throws Exception {
		dbConnection = con;
		namesToStatementStrings = statements;
	}
	
	/**
	 * Some databases do not support XML Column types in their JDBC drivers.  Setting this
	 * flag instructs the resolver to treat the XML column type as a CLOB and expects the
	 * SQL have appropriate XMLSERIALIZE/XMLPARSE statements included.
	 * @param treatClobAsXML
	 */
	public void setTreatClobAsXML(boolean treatClobAsXML) {
		this.treatClobAsXML = treatClobAsXML;
	}

	public boolean isTreatClobAsXML() {
		return treatClobAsXML;
	}

	/**
	 * At runtime, the uri passed is expected to be of form:
	 * 
	 * jdbc://namedquery?parm1val&parm2val&...%parmNval
	 * 
	 * The runtime will locate statement represented by namedquery, prepare the statement
	 * and assign the values passed each of the expected positional parameters.
	 * 
	 * @param uri A URI as described above
	 * @param base The base is not used by this resolver
	 */
	public XSequenceCursor getCollection(String uri, String base) {
		if (uri.startsWith(URI_SCHEME)) {
			ResultSet rs = null;
			
			XFactory factory = null;
			XItemFactory itemFact = null;
			try {
				factory = XFactory.newInstance();
				itemFact = factory.getItemFactory();
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println(e);
				return null;
			}
			
			try {
				// set end = everything after //
				String end = uri.substring(URI_SCHEME.length());
				String namedQuery = end;
				String paramVals[] = new String[0];
				// check to see if there is a query string with named parameters
				int indexOfQuestionMark = end.indexOf('?');
				if (indexOfQuestionMark != -1) {
					namedQuery = end.substring(0, indexOfQuestionMark);
					if (end.length() > indexOfQuestionMark + 1) {
						String queryString = end.substring(indexOfQuestionMark + 1);
						queryString = queryString.trim();
						if (queryString.length() > 0) {
							paramVals = queryString.split("&");
						}
					}
					
				}
				
				String query = namesToStatementStrings.get(namedQuery);
				//System.out.println("uri = " + uri);
				//System.out.println("named query = \"" + namedQuery + "\"");
				//System.out.println("query = " + query);
				
				PreparedStatement p = dbConnection.prepareStatement(query);
				int ii = 0;
				for (String val : paramVals) {
					p.setString(ii + 1, val);
					//System.out.println("setting " + ii + " to \"" + val + "\"");
					ii++;
				}
				ArrayList<XItemView> items = new ArrayList<XItemView>();
				rs = p.executeQuery();
				ResultSetMetaData metadata = rs.getMetaData();
				int colCount = metadata.getColumnCount();
				while (rs.next()) {
					for (int jj = 0 ; jj < colCount; jj++) {
						int colType = metadata.getColumnType(jj+1);
						String colName = metadata.getCatalogName(jj+1);
						XItemView item = null;
						switch (colType) {
							case Types.SQLXML:
								SQLXML sqlx = rs.getSQLXML(jj+1);
								StreamSource ss1 = sqlx.getSource(StreamSource.class);
								item = itemFact.item(ss1);
								sqlx.free();
								break;
							case Types.INTEGER:
								item = itemFact.item(rs.getInt(jj+1)); 
								break;
							case Types.VARCHAR:
							case Types.CHAR:
								item = itemFact.item(rs.getString(jj+1)); 
								break;
							case Types.CLOB:
								if (treatClobAsXML) {
									Clob clob = rs.getClob(jj+1);
									StreamSource ss2 = new StreamSource(clob.getAsciiStream());
									item = itemFact.item(ss2);
									clob.free();
									break;
								}
							default:
								System.out.println("Have not implemented a mapping for type " + colType + " in column " + colName);
								System.out.println("A mapping could be implemented, but is left to the user");
						}
						items.add(item);
					}
				}
				XItemView itemView[] = items.toArray(new XItemView[0]);
				XSequenceCursor seq = itemFact.sequence(itemView);
				return seq;
			}
			catch (SQLException sql) {
				System.out.println(sql);
				sql.printStackTrace();
				String databaseFailed = "databaseFailed";
				XSequenceCursor seq = itemFact.sequence(new String[] { databaseFailed });
				return seq;
			}
			catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
				return null;
			}
			finally {
				try {
					if (rs != null) {
						rs.close();
					}
				}
				catch (SQLException sqle) {
					System.out.println(sqle);
					sqle.printStackTrace();
				}
			}
		}
		else {
			return null;
		}
	}

}
