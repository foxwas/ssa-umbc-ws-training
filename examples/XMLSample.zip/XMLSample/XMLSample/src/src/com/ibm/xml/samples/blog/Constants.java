/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.blog;

import java.io.*;
import java.net.*;
import java.util.HashMap;

import javax.servlet.http.*;

import javax.xml.namespace.QName;

public class Constants {
	// some sample vulgar words to be used later in regular expressions
	private static final String[] VULGAR_WORD_LIST = {
		"darn",
		"shoot"
	};
	public static String VULGAR_WORDS = null; 
	static {
		StringBuffer sb = new StringBuffer();
		for (String item: VULGAR_WORD_LIST) {
			sb.append(item + "|");
		}
		sb.deleteCharAt(sb.length() - 1);
		VULGAR_WORDS = sb.toString();
	}
	
	public static final String ATOM_PREFIX = "atom";
	public static final String ATOM_NS = "http://www.w3.org/2005/Atom";
	
	public static final String MY_PREFIX = "my";
	public static final String MY_NS = "http://com.ibm.xml.samples";

	public static final QName PROFILE_ID_QNAME = new QName(MY_NS, "profileid");
	public static final QName VULGAR_NAMES_QNAME = new QName(MY_NS, "vulgarwords");
	public static final QName MONTHS_AGO_QNAME = new QName(MY_NS, "monthsAgo");
	public static final QName LEGACY_CONTENT_ANALYSIS_QNAME = new QName(MY_NS, "legacyContentAnalysis");

	public static final QName USEREMAIL_QNAME = new QName(MY_NS, "userEmail");
	public static final QName USERNAME_QNAME = new QName(MY_NS, "userName");
	public static final QName USERURI_QNAME = new QName(MY_NS, "userUri");
	
	public static final QName DATABASE_AVAILABLE_QNAME = new QName(MY_NS, "databaseAvailable");
	public static final QName DATABASE_CONFIG_QNAME = new QName(MY_NS, "databaseConfig");
	public static final QName TREAT_CLOB_AS_XML_QNAME = new QName(MY_NS, "treatClobAsXML");
	
	private static boolean treatClobAsXML = false;
	
	public static HashMap<String, String> dbStatementsSupportsSQLXML = null;
	public static HashMap<String, String> dbStatementsDoesNotSupportSQLXML = null;
	public static HashMap<String, String> dbStatements = null;
	
	// the fake value for a profile id to trigger loading data from local war resources
	public static final String fakeProfileId = "11111111111111111111";
	
	
	/**
	 * This method gets an input stream, either from the real Blogger web API's or from
	 * local files (when the fake profile id or blog id is specified)
	 */
	public static InputStream getInputStream(boolean blogs, String id) throws Exception {
		InputStream ret = null;
		if (blogs) { // blogs
			
			if (id.equals(fakeProfileId)) { // sentinel fake value
				ret = BloggerAPIsPrepared.class.getResourceAsStream("/sampledata/blogs-11111111111111111111.xml");
			}
			else {
				String allBlogs = "http://www.blogger.com/feeds/" + id + "/blogs";
				
				URL url = new URL(allBlogs);
				URLConnection connect = url.openConnection();
				ret = new BufferedInputStream(connect.getInputStream());
			}
		}
		else { // comments
			if (id.equals(fakeProfileId)) { // sentinel fake value
				ret = BloggerAPIsPrepared.class.getResourceAsStream("/sampledata/comments-11111111111111111111.xml");
			}
			else {
				String allComments = "http://www.blogger.com/feeds/" + id + "/comments/default";
	
				URL url = new URL(allComments);
				URLConnection connect = url.openConnection();
				ret = new BufferedInputStream(connect.getInputStream());
			}
		}
		
		return ret;
	}
	
	public static void setContentTypeBasedOnAccept(HttpServletRequest req, HttpServletResponse res) {
		String accept = req.getHeader("Accept");
		if (accept != null && accept.indexOf("application/xhtml+xml") != -1) {
			// browser supports XHTML
			res.setContentType("application/xhtml+xml");
		}
		else {
			// browser doesn't support XHTML - So tell the browser the output is basic HTML
			res.setContentType("text/html");
		}
	}

	public static void setTreatClobAsXML(boolean treatClobAsXML) {
		Constants.treatClobAsXML = treatClobAsXML;
		Constants.dbStatements = Constants.isTreatClobAsXML() ? Constants.dbStatementsDoesNotSupportSQLXML : Constants.dbStatementsSupportsSQLXML;
	}

	public static boolean isTreatClobAsXML() {
		return treatClobAsXML;
	}
}
