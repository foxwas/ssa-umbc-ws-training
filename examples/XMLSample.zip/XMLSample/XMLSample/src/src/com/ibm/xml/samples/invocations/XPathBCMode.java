/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import com.ibm.xml.xapi.*;

public class XPathBCMode {

	// The following XPath works on XPath 1.0. The XPath only works on XPath 2.0
	// if there is a single entry. If there are more than a single entry, XPath
	// 2.0 will throw and error stating there are two many entries in the
	// sequence as string-length expects a single value as input. However, since the
	// XPath 2.0 defines a XPath 1.0 backwards compatibility mode, the XPath will work
	// as expected when XPath 1.0 backwards compatibility mode.
	private static String XPATH_THAT_WORKED_ON_XPATH10 = "string-length(/atom:feed/atom:entry/atom:id)";

	// The following XPath works on all of XPath 1.0, XPath 2.0, and XPath 1.0
	// backwards compatibility mode due to the XPath specifically selecting the
	// first returned entry
	private static String XPATH_THAT_NOW_WORKS_ON_BOTH_XPATH10_AND_XPATH20 = "string-length(/atom:feed/atom:entry[1]/atom:id)";

	private static String INPUT_FILE = "/sampledata/comments-11111111111111111111.xml";

	/**
	 * @param args
	 */
	public static String execute() throws Exception {

		StringBuffer result = new StringBuffer();

		// Create the factory
		XFactory factory = XFactory.newInstance();

		XStaticContext sc = factory.newStaticContext();
		sc.declareNamespace("openSearch", "http://a9.com/-/spec/opensearchrss/1.0/");
		sc.declareNamespace("atom", "http://www.w3.org/2005/Atom");

		// Set XPath compatibility to XPath 1.0 backwards compatibility on a 2.0 processor
		sc.setXPathCompatibilityMode(XStaticContext.XPATH1_0_BC_COMPATIBILITY);
		
		// Create an XPath executable for the expression
		XPathExecutable xpath1 = factory.prepareXPath(XPATH_THAT_WORKED_ON_XPATH10, sc);

		// Create the input source
		Source source = new StreamSource(XPathBCMode.class.getResourceAsStream(INPUT_FILE));

		result.append("First XPath running in 1.0 backwards compatibility mode\n");

		// Execute the expression
		XSequenceCursor sequence = xpath1.execute(source);

		// Print out the result
		if (sequence != null) {
			do {
				result.append(sequence.getStringValue() + "\n");
			} while (sequence.toNext());
		}

		// Set XPath compatibility to XPath 2.0
		sc.setXPathCompatibilityMode(XStaticContext.XPATH2_0_PURE_COMPATIBILITY);

		// Create an XPath executable for the expression
		XPathExecutable xpath2 = factory.prepareXPath(XPATH_THAT_WORKED_ON_XPATH10, sc);

		// Create the input source
		source = new StreamSource(XPathBCMode.class.getResourceAsStream(INPUT_FILE));

		result.append("First XPath running in 2.0 mode\n");
		
		// create a dynamic context with a message handler to catch fatal error
		XDynamicContext dc = factory.newDynamicContext();
		MyMessageHandler mh = new MyMessageHandler();
		dc.setMessageHandler(mh);

		try {
			// Execute the expression
			sequence = xpath2.execute(source, dc);
		}
		catch (XProcessException xpe) {
			// we expect to catch an exception here
			sequence = null;
		}

		// Print out the result
		if (sequence != null) {
			do {
				result.append(sequence.getStringValue() + "\n");
			} while (sequence.toNext());
		} else {
			result.append("no results\n");
			result.append(mh.getMessages());
		}

		// Set XPath compatibility to XPath 2.0
		sc.setXPathCompatibilityMode(XStaticContext.XPATH2_0_PURE_COMPATIBILITY);

		// Create an XPath executable for the expression
		XPathExecutable xpath3 = factory.prepareXPath(XPATH_THAT_NOW_WORKS_ON_BOTH_XPATH10_AND_XPATH20, sc);

		// Create the input source
		source = new StreamSource(XPathBCMode.class.getResourceAsStream(INPUT_FILE));

		result.append("Second XPath running in 2.0 mode\n");

		// Execute the expression
		sequence = xpath3.execute(source);

		// Print out the result
		if (sequence != null) {
			do {
				result.append(sequence.getStringValue() + "\n");
			} while (sequence.toNext());
		}

		return result.toString();
	}
}
