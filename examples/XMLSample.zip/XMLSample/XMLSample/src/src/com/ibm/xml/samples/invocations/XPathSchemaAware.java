/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import java.io.*;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import com.ibm.xml.xapi.*;

public class XPathSchemaAware {

	// The following xml schema defines a complex type that references a base product identifier
	// substitution group (id) that is extended with various extensions (productid, barcore).
	// This pattern is a fairly typical pattern used in schemas to create extension hierarchies
	private static final String PRODUCT_XSD =
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
		"<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:samples=\"http://com.ibm.xml.samples\" targetNamespace=\"http://com.ibm.xml.samples\" elementFormDefault=\"qualified\" attributeFormDefault=\"unqualified\">" +
		"  <xs:element name=\"product\" type=\"samples:productType\"/>" +
		"" +
		"  <xs:complexType name=\"productType\">" +
		"    <xs:sequence>" +
		"      <xs:element ref=\"samples:id\"/>" +
		"    </xs:sequence>" +
		"  </xs:complexType>" +
		"" +
		"  <xs:element name=\"id\" type=\"xs:string\"/>" +
		"" +
		"  <xs:element name=\"productid\" substitutionGroup=\"samples:id\"/>" +
		"" +
		"  <xs:element name=\"barcode\" substitutionGroup=\"samples:id\"/>" +
		"</xs:schema>";

	// The following is an XML instance document that uses the head element in the substitution group (id)
	private static final String INSTANCE_DOC_USING_HEAD_ELEMENT =
		"<product xmlns:my=\"http://com.ibm.xml.samples\" xmlns=\"http://com.ibm.xml.samples\">" +
		"<id>ID from head type</id>" +
		"</product>";
	
	// The following is an XML instance document that uses a substition element (barcode)
	private static final String INSTANCE_DOC_USING_SUBSTITUTION_ELEMENT =
		"<product xmlns:my=\"http://com.ibm.xml.samples\" xmlns=\"http://com.ibm.xml.samples\">" +
		"<barcode>ID from substitution group type</barcode>" +
		"</product>";
	
	// The following is a XPath 2.0 statement that can correctly query either of the above documents.
	// Note the use of schema-element requires schema awareness to correctly understand the XML schema's
	// use of substitution groups.  With XPath 1.0, the XPath to do a similar query would have to query
	// every possible substitution group member instead of the head element.  Usually the application
	// does not know every substitution group member so using XPath 2.0 schema awareness makes this
	// scenario possible. 
	private static final String SCHEMA_AWARE_XPATH_WITH_HEAD_ELEMENT_STEP = "/my:product/schema-element(my:id)";

	public static String execute() throws Exception {
		StringBuffer result = new StringBuffer();

		// Create the factory
		XFactory factory = XFactory.newInstance();
		factory.registerSchema(new StreamSource(new StringReader(PRODUCT_XSD)));
		factory.setValidating(XFactory.FULL_VALIDATION);

		XStaticContext sc = factory.newStaticContext();
		sc.declareNamespace("my", "http://com.ibm.xml.samples");

		// Create an XPath executable for the expression
		XPathExecutable xpath1 = factory.prepareXPath(SCHEMA_AWARE_XPATH_WITH_HEAD_ELEMENT_STEP, sc);

		// Create the input source
		Source source = new StreamSource(new StringReader(INSTANCE_DOC_USING_HEAD_ELEMENT));

		// Execute the expression
		XSequenceCursor sequence = xpath1.execute(source);

		// Print out the result
		if (sequence != null) {
			do {
				result.append(sequence.getStringValue() + "\n");
			} while (sequence.toNext());
		}

		source = new StreamSource(new StringReader(INSTANCE_DOC_USING_SUBSTITUTION_ELEMENT));

		// Execute the expression
		sequence = xpath1.execute(source);

		// Print out the result
		if (sequence != null) {
			do {
				result.append(sequence.getStringValue() + "\n");
			} while (sequence.toNext());
		}
		
		return result.toString();
	}

}
