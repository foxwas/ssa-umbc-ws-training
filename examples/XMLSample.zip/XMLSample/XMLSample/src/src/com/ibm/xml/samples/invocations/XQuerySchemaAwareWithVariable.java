/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import java.io.StringWriter;

import javax.xml.namespace.QName;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import com.ibm.xml.xapi.XDynamicContext;
import com.ibm.xml.xapi.XFactory;
import com.ibm.xml.xapi.XOutputParameters;
import com.ibm.xml.xapi.XQueryExecutable;
import com.ibm.xml.xapi.XSequenceCursor;

public class XQuerySchemaAwareWithVariable {

    /**
     * @param xqueryFile - an xq file that contains an XQuery expression (or set of expressions)
     * @param xmlInputFile - an XML file that contains the data to run the XQuery expression against
     * @param varName - the variable name (must be declared in the XQuery expression)
     * @param varValue - the string representation of the variable value
     */
    public static String execute(String xmlInputFile, String xqueryFile,
            String varName, String varValue) throws Exception {

        // Create the factory, set validation to force type assessment
        XFactory factory = XFactory.newInstance();
        factory.setValidating(XFactory.FULL_VALIDATION);
        factory.registerSchema(new StreamSource(XQuerySchemaAwareWithVariable.class.getResourceAsStream("/sampledata/salesWithNamespace.xsd")));

        // Create a StreamSource for the query
        StreamSource query = new StreamSource(XQuerySchemaAwareWithVariable.class.getResourceAsStream(xqueryFile));

        // Create an XQuery executable
        XQueryExecutable executable = factory.prepareXQuery(query);

        // Create the input source
        Source source = new StreamSource(XQuerySchemaAwareWithVariable.class.getResourceAsStream(xmlInputFile));

        // Create the dynamic context and bind the variable value
        XDynamicContext dynamicContext = factory.newDynamicContext();
        MyMessageHandler mh = new MyMessageHandler();
        dynamicContext.setMessageHandler(mh);
        dynamicContext.bind(new QName(varName), varValue);

        // Execute the query
        XSequenceCursor sequence = null;
        try {
            sequence = executable.execute(source, dynamicContext);
        } catch (Exception e) {
            // For invalid expression a fatal error will occur
        }
        
        if (sequence == null) {
            return "no results\n" + mh.getMessages();
        }

        // Print the result
        StringWriter sw = new StringWriter();
        XOutputParameters outParams = factory.newOutputParameters();
        outParams.setIndent(true);
        outParams.setOmitXMLDeclaration(true);
        Result result = new StreamResult(sw);
        sequence.exportSequence(result, outParams);
        
        if (mh.getMessages().length() > 0) {
            sw.append("\n\nMessages:\n");
            sw.append(mh.getMessages());
        }

        return sw.toString();
    }
}
