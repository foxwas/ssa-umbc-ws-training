/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import java.io.ByteArrayOutputStream;
import java.net.URL;

import javax.xml.transform.*;
import javax.xml.transform.stream.*;

import com.ibm.xml.xapi.*;

public class XSLTSchemaAware {
	
    /**
     * @param args
     */
    public static String execute(String inputfile, String xsltfile) throws Exception {
	    // Create the factory, set validation to force type assessment
	    XFactory factory = XFactory.newInstance();
	    factory.setValidating(XFactory.FULL_VALIDATION);
	    factory.registerSchema(new StreamSource(XSLTSchemaAware.class.getResourceAsStream("/sampledata/salesWithNamespace.xsd")));
	    
	    // Create the source from a file
	    // Loading this via URL allows relative import-schema's to work
	    URL xsltfileURL = XSLTSchemaAware.class.getResource(xsltfile);
	    StreamSource source = new StreamSource(xsltfileURL.toString());

	    // Create an XSL transform executable for the expression
	    XSLTExecutable xslTransform = factory.prepareXSLT(source);
	    
	    // Create the input source and result
	    StreamSource input = new StreamSource(XSLTSchemaAware.class.getResourceAsStream(inputfile));
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    Result result = new StreamResult(baos);
	    
        // Create a dynamic context and associate an message handler
        XDynamicContext dc = factory.newDynamicContext();
        MyMessageHandler mh = new MyMessageHandler();
        dc.setMessageHandler(mh);
	    
	    // Execute the transformation
	    try {
	    	xslTransform.execute(input, dc, result);
	    }
	    catch (Exception e) {
	    	// for invalid output and temporary trees, we'll get a fatal error due to validation=strict
	    }
	    
        if (baos.size() == 0) {
			return "no results\n" + mh.getMessages();
        }
	    
    	return baos.toString();
    }
}
