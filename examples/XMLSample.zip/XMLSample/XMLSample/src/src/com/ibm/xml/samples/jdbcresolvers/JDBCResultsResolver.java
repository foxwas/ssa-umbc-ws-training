/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.jdbcresolvers;

import java.sql.*;
import java.util.*;
import java.io.*;

import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

import com.ibm.xml.xapi.*;

public class JDBCResultsResolver implements XResultResolver {
	private static String URI_SCHEME = "jdbc://";
	private static String XML_KEYWORD = "--XML--";

	private Connection dbConnection;
	private HashMap<String, String> namesToStatementStrings;
	private boolean treatClobAsXML = false;
	
    private ArrayList<ResultContextHolder> contexts = new ArrayList<ResultContextHolder>();
	
    /**
	 * Create a results resolver that can resolve named statements with parameterized values
	 * to JDBC update/insert statements.
     * @param con Any JDBC connection
     * @param statements A collection of named statements to update/insert
     * @throws Exception
     */
	public JDBCResultsResolver(Connection con, HashMap<String, String> statements) throws Exception {
		dbConnection = con;
		namesToStatementStrings = statements;
	}
	
	/**
	 * Some databases do not support XML Column types in their JDBC drivers.  Setting this
	 * flag instructs the resolver to treat the XML column type as a CLOB and expects the
	 * SQL have appropriate XMLSERIALIZE/XMLPARSE statements included.
	 * @param treatClobAsXML
	 */
	public void setTreatClobAsXML(boolean treatClobAsXML) {
		this.treatClobAsXML = treatClobAsXML;
	}

	public boolean isTreatClobAsXML() {
		return treatClobAsXML;
	}
	
	/**
	 * At runtime, the uri passed is expected to be of form:
	 * 
	 * jdbc://namedquery?parm1val&--XML--&...%parmNval
	 * 
	 * The runtime will locate statement represented by namedquery, prepare the statement
	 * and assign the values passed each of the expected positional parameters.  The
	 * resulting XML will be stored in whichever positional parameter has "--XML--" as its
	 * value.
	 * 
	 * @param uri A URI as described above
	 * @param base The base is not used by this resolver
	 */
	public Result getResult(String uri, String base) {
		if (uri.startsWith(URI_SCHEME)) {
			// set end = everything after //
			String end = uri.substring(URI_SCHEME.length());
			String namedQuery = end;
			String paramVals[] = new String[0];
			// check to see if there is a query string with named parameters
			int indexOfQuestionMark = end.indexOf('?');
			if (indexOfQuestionMark != -1) {
				namedQuery = end.substring(0, indexOfQuestionMark);
				if (end.length() > indexOfQuestionMark + 1) {
					String queryString = end.substring(indexOfQuestionMark + 1);
					queryString = queryString.trim();
					if (queryString.length() > 0) {
						paramVals = queryString.split("&");
					}
				}
				
			}
			
			try {
				ResultContextHolder rch = new ResultContextHolder();
				String query = namesToStatementStrings.get(namedQuery);
				
				//System.out.println("uri = " + uri);
				//System.out.println("named query = \"" + namedQuery + "\"");
				//System.out.println("query = " + query);
				
				rch.updateStatement = dbConnection.prepareStatement(query);
				int ii = 0;
				for (String val : paramVals) {
					if (val.equals(XML_KEYWORD)) {
						if (!treatClobAsXML) {
							SQLXML xml = dbConnection.createSQLXML();
							OutputStream os = xml.setBinaryStream();
							rch.result = new StreamResult(os);
							rch.updateStatement.setSQLXML(ii + 1, xml);
						}
						else {
							rch.clobBaos = new ByteArrayOutputStream();
							rch.result = new StreamResult(rch.clobBaos);
							rch.xmlPosition = ii + 1;
						}
					}
					else {
						rch.updateStatement.setString(ii + 1, val);
					}
					//System.out.println("setting " + ii + " to \"" + val + "\"");
					ii++;
				}
				if (rch.result == null) {
					throw new SQLException("did not encounter a XML parameter - please ensure parameter values have \"--XML--\" as one parameter value");
				}
				contexts.add(rch);
				return rch.result;
			}
			catch (SQLException sqle) {
				sqle.printStackTrace();
				return null;
			}
		}
		else {
			return null;
		}
	}
	
	/**
	 * Execute all outstanding inserts and creates.  Must be called after the XML runtime is complete
	 * with writing to all results (typically this is after a XSLT executable execute() method is
	 * called.
	 * @throws Exception
	 */
	public void executeUpdates() throws Exception {
		for (ResultContextHolder item : contexts) {
			if (treatClobAsXML) {
				byte resultsB[] = item.clobBaos.toByteArray();
				item.clobBaos.close();
				
				ByteArrayInputStream bais = new ByteArrayInputStream(resultsB);
		
				item.updateStatement.setAsciiStream(item.xmlPosition, bais, resultsB.length);
				item.updateStatement.executeUpdate();
				dbConnection.commit();
			}
			else {
				item.updateStatement.executeUpdate();
				dbConnection.commit();
			}
		}
	}
}

class ResultContextHolder {
	PreparedStatement updateStatement;
	int xmlPosition;
	Result result;
	// only used for treatClobAsXML
	ByteArrayOutputStream clobBaos;
}
