/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import java.io.ByteArrayOutputStream;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import com.ibm.xml.xapi.XFactory;
import com.ibm.xml.xapi.XSLTExecutable;
import com.ibm.xml.xapi.XStaticContext;

public class XSLTBCMode {
	
	// The following samples shows a typical scenario when moving a stylesheet from XSLT 1.0 to 2.0
	// The stylesheet, if run with a version of "1.0" on XSLT 1.0 processor would return only the
	// first result, even though there were more than one match in the select result.  The stylesheet
	// would return <out><one>Jane</one></out>.
	
	// Moving the stylesheet to a XSLT 2.0 processor, while changing the version to "2.0" will result
	// in different output <out><one>Jane Jim John</one></out>.  This behavior is shown by
	// XSLT_BROKEN_20_PROCESSOR_IN_20_MODE.
	
	// An option to avoid this problem is to keep the version at "1.0" while running on a 2.0 processor
	// which is shown by XSLT_BROKEN_20_PROCESSOR_FIXED_BY_10_BC_MODE.  Changing the version to "1.0" in the
	// stylesheet instructs the processor to run in XSLT 1.0 backwards compatibility mode.
	
	// Another option to avoid this problem is to fix the stylesheet to explicitly work on both 1.0
	// and 2.0 processors by specifically selecting the first item. Then the stylesheet will work on
	// both 2.0 processors in normal mode (shown by XSLT_FIXED_20_PROCESSOR_IN_20_MODE) and 1.0 processors.
	
	private static String XSLT_BROKEN_20_PROCESSOR_IN_20_MODE = "/samplexslts/xsltBroken20ProcessorIn20Mode.xsl";
	private static String XSLT_BROKEN_20_PROCESSOR_FIXED_BY_10_BC_MODE = "/samplexslts/xsltBroken20ProcessorFixedBy10BCMode.xsl";
	private static String XSLT_FIXED_20_PROCESSOR_IN_20_MODE = "/samplexslts/xsltFixed20ProcessorIn20Mode.xsl";

	private static String INPUT_FILE = "/sampledata/names.xml";

	public static String execute() throws Exception {
		
		// Create the factory
		XFactory factory = XFactory.newInstance();

		// Create the static context
		XStaticContext sc = factory.newStaticContext();
		
		// Hold the results from the transformation
		String result1 = null;
        
        // A value to hold the results to be printed on the jsp page
        StringBuffer printableResults = new StringBuffer();

        // Run the transformation with backwards compatibility mode turned on
        printableResults.append("\"Broken\" XSLT running in 2.0 that assumes 1.0 behavior\n");
        StreamSource source1 = new StreamSource(XSLTBCMode.class.getResourceAsStream(XSLT_BROKEN_20_PROCESSOR_IN_20_MODE));
		result1 = runTransformation(factory, sc, source1);
		
		// Add results from first transform to the printableResults
        printableResults.append(result1 + "\n");
                
        // Run the transformation with backwards compatibility mode turned off
    	printableResults.append("\"Fix\" the problem by running in 1.0 backwards compatibility mode\n");
    	source1 = new StreamSource(XSLTBCMode.class.getResourceAsStream(XSLT_BROKEN_20_PROCESSOR_FIXED_BY_10_BC_MODE));
        result1 = runTransformation(factory, sc, source1);
        
        // Add results from second transformation to the printableResults
        printableResults.append(result1 + "\n");
        
        // Run the transformation with backwards compatibility mode turned on
    	printableResults.append("\"Fix\" the problem by changing the stylesheet to work in 2.0 and 1.0\n");
        StreamSource source2 = new StreamSource(XSLTBCMode.class.getResourceAsStream(XSLT_FIXED_20_PROCESSOR_IN_20_MODE));
		result1 = runTransformation(factory, sc, source2);
		
		// Add results from first transform to the printableResults
        printableResults.append(result1 + "\n");
                
		return printableResults.toString();
	}

	private static String runTransformation(XFactory factory, XStaticContext sc, StreamSource source) {
		
		// Create an XSL transform executable for the expression
		XSLTExecutable xslTransform = factory.prepareXSLT(source, sc);

		// Create the input source and result
        Source input = new StreamSource(XSLTBCMode.class.getResourceAsStream(INPUT_FILE));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Result result = new StreamResult(baos);
        
        // Execute the transformation
        xslTransform.execute(input, result);
               
		return baos.toString();
				
	}

}
