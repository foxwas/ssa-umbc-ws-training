/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.blog;

import java.io.IOException;

import javax.servlet.http.*;
import javax.servlet.*;

import com.ibm.xml.xapi.*;

import javax.xml.datatype.*;
import javax.xml.namespace.*;
import javax.xml.transform.stream.*;

public class CheckerXQueryServlet extends HttpServlet {
	private static XFactory factory;
	private static XQueryExecutable getAllBlogs;
	private static XQueryExecutable getAllComments;
	private static XOutputParameters outParms;
	
	
	/**
	 * This method compiles the XSLT executables once and since they are thread safe, stores them
	 * statically to be reused by all callers.  This method would typically be called by servlet
	 * and EJB initialization and could be reused until the application is restarted.
	 * @throws Exception
	 */
	private static void initializeXQueries() throws Exception {
		factory = XFactory.newInstance();
		
		outParms = factory.newOutputParameters();
		outParms.setMediaType(XOutputParameters.METHOD_XHTML);
		outParms.setDoctypePublic("-//W3C//DTD XHTML 1.0 Transitional//EN");
		outParms.setDoctypeSystem("http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
		outParms.setOmitXMLDeclaration(false);
		outParms.setIndent(true);
		
		getAllBlogs = factory.prepareXQuery(new StreamSource(CheckerXQueryServlet.class.getResourceAsStream("/samplexqs/allblogs.xq")));
		
		XStaticContext sc = factory.newStaticContext();
		sc.declareFunction(Constants.LEGACY_CONTENT_ANALYSIS_QNAME, XTypeConstants.BOOLEAN_QNAME, new QName[] { XTypeConstants.STRING_QNAME });
		
		getAllComments = factory.prepareXQuery(new StreamSource(CheckerXQueryServlet.class.getResourceAsStream("/samplexqs/allcomments.xq")), sc);
	}

	/**
	 * Do a pre-compile of the XPath's used in this sample at servlet init time
	 */
	public void init(ServletConfig sc) throws ServletException {
		super.init(sc);
		
		try {
			initializeXQueries();
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
	}
	
	/**
	 * A rather basic servlet to dispatch to the XPath focused code
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String action = request.getParameter("action");
			if (action == null) {
				throw new ServletException("invalid action in post parameters");
			} else if (action.equals("getallblogs")) {
				String profileid = request.getParameter("profileid");
				doGetAllBlogs(profileid, request, response);
			} else if (action.equals("getallcomments")){
				String blogid = request.getParameter("blogid");
				String monthsAgoS = request.getParameter("monthsAgo");
				int monthsAgo = 12;
				try {
					if (monthsAgoS != null) {
						monthsAgo = Integer.parseInt(monthsAgoS);
					}
				}
				catch (NumberFormatException nfe) {
					nfe.printStackTrace();
				}
				doGetAllComments(blogid, monthsAgo, request, response);
			}
			else {
				throw new ServletException("invalid action in post parameters");
			}
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	private void doGetAllBlogs(String profileId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		XDynamicContext dc = factory.newDynamicContext();
		
		dc.bind(Constants.PROFILE_ID_QNAME, profileId);
		
		StreamSource input = new StreamSource(Constants.getInputStream(true, profileId));
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());
		
		XSequenceCursor seq = getAllBlogs.execute(input, dc);
		seq.exportSequence(output, outParms);
	}
	
	private void doGetAllComments(String blogId, int monthsAgo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		XDynamicContext dc = factory.newDynamicContext();
		
		dc.bind(Constants.VULGAR_NAMES_QNAME, Constants.VULGAR_WORDS);

		// Bind a XML Duration for the number of months specified
		Duration dMonthsAgo = DatatypeFactory.newInstance().newDurationYearMonth(true, 0, monthsAgo);
		dc.bind(Constants.MONTHS_AGO_QNAME, dMonthsAgo);
		
		dc.bindFunction(Constants.LEGACY_CONTENT_ANALYSIS_QNAME, ExtensionFunctions.class.getMethod("legacyContentAnalysis", String.class));
		
		StreamSource input = new StreamSource(Constants.getInputStream(false, blogId));
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());

		XSequenceCursor seq = getAllComments.execute(input, dc);
		seq.exportSequence(output, outParms);
	}
}
