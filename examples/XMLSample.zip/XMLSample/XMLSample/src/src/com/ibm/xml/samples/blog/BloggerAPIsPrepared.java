/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.blog;

import java.io.*;
import java.util.*;
import javax.xml.datatype.*;

import javax.xml.transform.stream.*;
import javax.xml.transform.*;
import javax.xml.namespace.*;
import com.ibm.xml.xapi.*;

public class BloggerAPIsPrepared {
	
	// fairly simple XPath example used in getAllBlogs
	private static String XPATH_GET_ALL_BLOGS = "/atom:feed/atom:entry[substring-after(atom:id, '.blog-')]/(atom:id,atom:title)";
	
	// more sophisticated XPath examples used in getAllQuestionableComments
	private static String XPATH_GET_ALL_QUESTIONABLE_COMMENTS =
		"(" +
			// simple predicate matching
			"/atom:feed/atom:entry[atom:author/atom:name = 'Anonymous'] | " + 
			// demonstration of variable binding, usage of XPath 2.0 regular expression support
			"/atom:feed/atom:entry[matches(atom:content, $my:vulgarwords, 'i')] | " +
			// demonstration of user defined extension function binding
			"/atom:feed/atom:entry[my:legacyContentAnalysis(atom:content/text())]" +
		")" +
		// demonstration of XPath 2.0 date handling
		"[atom:published > current-dateTime() - $my:monthsAgo]" +
		"/(atom:id/text(),atom:published,atom:content/text(),atom:link[@rel='edit']/@href,atom:author/atom:name/text())";
	
	private static final boolean DEBUG = false;

	private static XPathExecutable getAllBlogsXPath;
	private static XPathExecutable getAllQuestionableCommentsXPath;
	
	/**
	 * This method compiles the XPath executables once and since they are thread safe, stores them
	 * statically to be reused by all callers.  This method would typically be called by servlet
	 * and EJB initialization and could be reused until the application is restarted.
	 * @throws Exception
	 */
	public static void initializeXPaths() throws Exception {
		XFactory factory = XFactory.newInstance();
		
        XStaticContext sc1 = factory.newStaticContext();
        sc1.setUseCompiler(true);
        sc1.declareNamespace("atom", "http://www.w3.org/2005/Atom");
        
		getAllBlogsXPath = factory.prepareXPath(XPATH_GET_ALL_BLOGS, sc1);

		XStaticContext sc2 = factory.newStaticContext();
        sc2.setUseCompiler(true);
		sc2.declareNamespace(Constants.ATOM_PREFIX, Constants.ATOM_NS);
		sc2.declareNamespace(Constants.MY_PREFIX, Constants.MY_NS);
		
		sc2.declareVariable(Constants.VULGAR_NAMES_QNAME, XTypeConstants.STRING_QNAME);
		sc2.declareVariable(Constants.MONTHS_AGO_QNAME, XTypeConstants.YEARMONTHDURATION_QNAME);
		sc2.declareFunction(Constants.LEGACY_CONTENT_ANALYSIS_QNAME, XTypeConstants.BOOLEAN_QNAME, new QName[] { XTypeConstants.STRING_QNAME });
		
		getAllQuestionableCommentsXPath = factory.prepareXPath(XPATH_GET_ALL_QUESTIONABLE_COMMENTS, sc2);
	}
	
	/**
	 * This function takes a profileid and returns a list of all blogs to which that user contributes
	 * http://code.google.com/apis/blogger/docs/2.0/developers_guide_protocol.html#RetrievingMetafeed
	 * @param profileId profileid
	 * @return list of BlogBeans
	 * @throws Exception
	 */
	public static List<BlogBean> getAllBlogs(String profileId) throws Exception {
    	if (DEBUG) {
    		System.out.println("Running prepared version of " + XPATH_GET_ALL_BLOGS);
    	}
    	
		InputStream is = Constants.getInputStream(true, profileId);
		
		List<BlogBean> ret = new ArrayList<BlogBean>();
		
		// Create the input source
		Source source = new StreamSource(is);

		// Execute the expression
		XSequenceCursor sequence = getAllBlogsXPath.execute(source, null);

		if (sequence != null) {
			do {
				String blogid = sequence.getStringValue();
				int index = blogid.indexOf("blog-");
				if (index != -1) {
					blogid = blogid.substring(index + "blog-".length());
				}
				// this is to propagate the fact that the user used the fake profileid
				if (profileId.equals(Constants.fakeProfileId)) {
					blogid = Constants.fakeProfileId;
				}
				sequence.toNext();
				String blogtitle = sequence.getStringValue();
				BlogBean bb = new BlogBean(blogid, blogtitle);
				ret.add(bb);
			} while (sequence.toNext());
		}
        
        return ret;
	}
	
	/**
	 * This function takes a blogid and returns a list of all comments on that blog that match
	 * criteria identified as questionable
	 * http://code.google.com/apis/blogger/docs/2.0/developers_guide_protocol.html#RetrievingComments
	 * @param blogId blog id
	 * @param monthsAgo how many months back should be searched
	 * @return list of CommentBeans that are within time duration and have questionable criteria
	 * @throws Exception
	 */
	public static List<CommentBean> getAllQuestionableComments(String blogId, int monthsAgo) throws Exception {
    	if (DEBUG) {
    		System.out.println("Running prepared version of " + XPATH_GET_ALL_QUESTIONABLE_COMMENTS);
    	}
    	
		InputStream is = Constants.getInputStream(false, blogId);

		List<CommentBean> ret = new ArrayList<CommentBean>();

		XFactory factory = XFactory.newInstance();
		
		// Create the input source
		Source source = new StreamSource(is);
		
		XDynamicContext dc = factory.newDynamicContext();
		dc.bind(Constants.VULGAR_NAMES_QNAME, Constants.VULGAR_WORDS);

		// Bind a XML Duration for the number of months specified
		Duration dMonthsAgo = DatatypeFactory.newInstance().newDurationYearMonth(true, 0, monthsAgo);
		dc.bind(Constants.MONTHS_AGO_QNAME, dMonthsAgo);
		
		dc.bindFunction(Constants.LEGACY_CONTENT_ANALYSIS_QNAME, ExtensionFunctions.class.getMethod("legacyContentAnalysis", String.class));

		// Execute the expression
		XSequenceCursor sequence = getAllQuestionableCommentsXPath.execute(source, dc);

		if (sequence != null) {
			do {
            	String id = sequence.getStringValue();
            	int index = id.indexOf("post-");
            	if (index != -1) {
            		id = id.substring(index + "post-".length());
            	}
            	sequence.toNext();
            	XMLGregorianCalendar published = sequence.getDateTimeValue();
            	Date publishedDate = published.toGregorianCalendar().getTime();
            	sequence.toNext();
            	String comment = sequence.getStringValue();
            	sequence.toNext();
            	String editurl = sequence.getStringValue();
            	sequence.toNext();
            	String author = sequence.getStringValue();
            	CommentBean b = new CommentBean(id, author.equals("Anonymous"), author, comment, editurl, publishedDate);
            	ret.add(b);
			} while (sequence.toNext());
		}
		
		return ret;
	}
}
