/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import javax.xml.transform.stream.StreamSource;

import com.ibm.xml.xapi.*;

/**
 * A fairly simple instance of a collection resolver that returns
 * a sequence that contains the sales and products xml files
 * based of a collection name of "mycollection".
 */
public class MyCollectionResolver implements XCollectionResolver {

	public XSequenceCursor getCollection(String uri, String base) {
		
		XSequenceCursor collection = null;
		try {
			if (uri.equals("mycollection")) {
				// Create stream sources for the xml documents
				StreamSource source1 = new StreamSource(MyCollectionResolver.class.getResourceAsStream("/sampledata/sales.xml"));
				StreamSource source2 = new StreamSource(MyCollectionResolver.class.getResourceAsStream("/sampledata/products.xml"));
				
				XFactory factory = XFactory.newInstance();
				XItemFactory itemFactory = factory.getItemFactory();
				
				// Create item views for the sources
				XItemView items[] = {
						itemFactory.item(source1),
						itemFactory.item(source2)
				};
				
				// Create a sequence of the item views
				collection = itemFactory.sequence(items);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return collection;
	}
	
}
