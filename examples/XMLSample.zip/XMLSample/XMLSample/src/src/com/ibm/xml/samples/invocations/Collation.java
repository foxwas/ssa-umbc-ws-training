/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.invocations;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.xml.transform.*;
import javax.xml.transform.stream.*;

import com.ibm.xml.xapi.*;

public class Collation {
	
    public static String executeGermanCollationXPath(String xpathS) throws Exception {
    	StringBuffer result = new StringBuffer();
    	
        // Create the factory and a dynamic context that registers a collation
        XFactory factory = XFactory.newInstance();
        XDynamicContext dc = factory.newDynamicContext();
        Collator c = (Collator)Collator.getInstance(Locale.GERMAN).clone();
        c.setStrength(Collator.PRIMARY);
        dc.bindCollation("http://german/collation", c);
        
        // Create an XSL transform executable for the expression
        XPathExecutable xpath = factory.prepareXPath(xpathS);
        
        // Execute the expression
        XSequenceCursor sequence = xpath.execute(dc);
        
        // Print out the result
        if (sequence != null) {
            do {
            	result.append(sequence.getStringValue() + "\n");
            } while (sequence.toNext());
        }
        
        return result.toString();
    }
    
    public static String executeGermanCollationXSLT(String inputfile, String xsltfile) throws Exception {
    	// Create the factory and a dynamic context that registers a collation
        XFactory factory = XFactory.newInstance();
        XDynamicContext dc = factory.newDynamicContext();
        Collator c = (Collator)Collator.getInstance(Locale.GERMAN).clone();
        c.setStrength(Collator.PRIMARY);
        dc.bindCollation("http://german/collation", c);
        
        // Create the source from a file
        StreamSource source = new StreamSource(Collation.class.getResourceAsStream(xsltfile));

        // Create an XSL transform executable for the expression
        XSLTExecutable xslTransform = factory.prepareXSLT(source);
        
        // Create the input source and result
        Source input = new StreamSource(Collation.class.getResourceAsStream(inputfile));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Result result = new StreamResult(baos);
        
        // Execute the transformation
        xslTransform.execute(input, dc, result);
        return baos.toString();
    }
    
    public static String executeGermanCollationXQuery(String inputfile, String xqfile) throws Exception {
    	// Create the factory
    	XFactory factory = XFactory.newInstance();
    	XDynamicContext dc = factory.newDynamicContext();
        Collator c = (Collator)Collator.getInstance(Locale.GERMAN).clone();
        c.setStrength(Collator.PRIMARY);
        dc.bindCollation("http://german/collation", c);
    	
        // Create a StreamSource for the query
    	StreamSource query = new StreamSource(SimpleXQuery.class.getResourceAsStream(xqfile));

        // Create the input source
        Source source = new StreamSource(SimpleXQuery.class.getResourceAsStream(inputfile));

        // Create an XQuery executable
        XQueryExecutable executable = factory.prepareXQuery(query);

        // Execute the expression
        XSequenceCursor sequence = executable.execute(source, dc);

        // Print the result
    	StringWriter sw = new StringWriter();
    	XOutputParameters outParams = factory.newOutputParameters();
    	outParams.setIndent(true);
        Result result2 = new StreamResult(sw);
        sequence.exportSequence(result2, outParams);

        return sw.toString();
    }
}
