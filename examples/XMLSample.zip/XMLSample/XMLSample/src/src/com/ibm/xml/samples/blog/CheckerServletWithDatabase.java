/*
COPYRIGHT LICENSE:  This information contains sample code provided in source
code form. You may copy, modify, and distribute these sample programs in any
form without payment to IBM for the purposes of developing, using, marketing
or distributing application programs conforming to the application programming
interface for the operating platform for which the sample code is written.
Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE
ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE,
AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT 
OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE 
SAMPLE SOURCE CODE.
*/

package com.ibm.xml.samples.blog;

import java.util.HashMap;
import java.io.IOException;

import javax.servlet.http.*;
import javax.servlet.*;

import com.ibm.xml.samples.jdbcresolvers.JDBCCollectionResolver;
import com.ibm.xml.samples.jdbcresolvers.JDBCResultsResolver;
import com.ibm.xml.xapi.*;

import javax.xml.datatype.*;
import javax.xml.namespace.*;
import javax.xml.transform.stream.*;

import java.sql.*;

import javax.sql.*;
import javax.naming.*;

public class CheckerServletWithDatabase extends HttpServlet {
	private static XFactory factory;
	private static XOutputParameters outParms;
	
	private static XQueryExecutable getAllBlogs;
	private static XQueryExecutable getAllComments;
	private static XSLTExecutable updateDatabaseWeb;
	private static XSLTExecutable viewDatabase;
	
	private static InitialContext jndiContext;
	private static DataSource datasource;
	
	private static final String DATASOURCE_JNDI_NAME = "java:comp/env/jdbc/XMLDataSourceDB";
	
	/**
	 * This method compiles the executables once and since they are thread safe, stores them
	 * statically to be reused by all callers.  This method would typically be called by servlet
	 * and EJB initialization and could be reused until the application is restarted.
	 * @throws Exception
	 */
	private static void initializeXMLArtifacts() throws Exception {
		factory = XFactory.newInstance();
		
		outParms = factory.newOutputParameters();
		outParms.setMediaType(XOutputParameters.METHOD_XHTML);
		outParms.setDoctypePublic("-//W3C//DTD XHTML 1.0 Transitional//EN");
		outParms.setDoctypeSystem("http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
		outParms.setOmitXMLDeclaration(false);
		outParms.setIndent(true);
		
		getAllBlogs = factory.prepareXQuery(new StreamSource(CheckerServletWithDatabase.class.getResourceAsStream("/samplexqs/allblogsWithDatabase.xq")));
		
		XStaticContext sc = factory.newStaticContext();
		sc.declareFunction(Constants.LEGACY_CONTENT_ANALYSIS_QNAME, XTypeConstants.BOOLEAN_QNAME, new QName[] { XTypeConstants.STRING_QNAME });
		
		getAllComments = factory.prepareXQuery(new StreamSource(CheckerServletWithDatabase.class.getResourceAsStream("/samplexqs/allcommentsWithDatabase.xq")), sc);
		
		updateDatabaseWeb = factory.prepareXSLT(new StreamSource(CheckerServletWithDatabase.class.getResourceAsStream("/samplexslts/updatedatabaseWeb.xsl")));
		viewDatabase = factory.prepareXSLT(new StreamSource(CheckerServletWithDatabase.class.getResourceAsStream("/samplexslts/viewdatabase.xsl")));
	}
	
	/**
	 * This method sets up the named queries for later use with Resolvers.  It will also
	 * @throws Exception
	 */
	public void initializeDatabase() throws Exception {
		
		Constants.dbStatementsSupportsSQLXML = new HashMap<String, String>();
		Constants.dbStatementsSupportsSQLXML.put("getAllSpammers", "SELECT DOMAINNAME, CONTACTS from SPAMMERS");
		Constants.dbStatementsSupportsSQLXML.put("getAuthorsWhoHaveSpammedFromDomain", "SELECT CONTACTS from SPAMMERS where DOMAINNAME = ?");
		Constants.dbStatementsSupportsSQLXML.put("updateAuthorsWhoHaveSpammedByDomain", "UPDATE SPAMMERS SET CONTACTS = ? WHERE DOMAINNAME = ?");
		Constants.dbStatementsSupportsSQLXML.put("insertAuthorsWhoHaveSpammedByDomain", "INSERT INTO SPAMMERS (CONTACTS, DOMAINNAME) VALUES (?, ?)");
		
		Constants.dbStatementsDoesNotSupportSQLXML = new HashMap<String, String>();
		Constants.dbStatementsDoesNotSupportSQLXML.put("getAllSpammers", "SELECT DOMAINNAME, XMLSERIALIZE (CONTACTS AS CLOB) from SPAMMERS");
		Constants.dbStatementsDoesNotSupportSQLXML.put("getAuthorsWhoHaveSpammedFromDomain", "SELECT XMLSERIALIZE (CONTACTS AS CLOB) from SPAMMERS where DOMAINNAME = ?");
		Constants.dbStatementsDoesNotSupportSQLXML.put("updateAuthorsWhoHaveSpammedByDomain", "UPDATE SPAMMERS SET CONTACTS = XMLPARSE(DOCUMENT CAST (? AS CLOB) PRESERVE WHITESPACE) WHERE DOMAINNAME = ?");
		Constants.dbStatementsDoesNotSupportSQLXML.put("insertAuthorsWhoHaveSpammedByDomain", "INSERT INTO SPAMMERS (CONTACTS, DOMAINNAME) VALUES (XMLPARSE(DOCUMENT CAST (? AS CLOB) PRESERVE WHITESPACE), ?)");
		
		Constants.dbStatements = Constants.isTreatClobAsXML() ? Constants.dbStatementsDoesNotSupportSQLXML : Constants.dbStatementsSupportsSQLXML;
		
		try {
			jndiContext = new InitialContext();
			datasource = (DataSource)jndiContext.lookup(DATASOURCE_JNDI_NAME);
			if (datasource == null) {
				System.out.println("Database lookup failed, please define a datasource with name: 'XMLDataSourceDB and JNDI name: 'XMLDataSource'");
			}
		}
		catch (Exception e) {
			System.out.println("Database lookup failed, please define a datasource with name: 'XMLDataSourceDB and JNDI name: 'XMLDataSource'");
		    System.out.println(e);
			e.printStackTrace();
		}
	}

	/**
	 * Do a pre-compile of the XPath's used in this sample at servlet init time
	 */
	public void init(ServletConfig sc) throws ServletException {
		super.init(sc);
		
		try {
			initializeXMLArtifacts();
			initializeDatabase();
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
	}
	
	/**
	 * A rather basic servlet to dispatch to the XPath focused code
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String action = request.getParameter("action");
			if (action == null) {
				throw new ServletException("invalid action in post parameters");
			} else if (action.equals("getallblogs")) {
				String profileid = request.getParameter("profileid");
				doGetAllBlogs(profileid, request, response);
			} else if (action.equals("getallcomments")){
				String blogid = request.getParameter("blogid");
				String monthsAgoS = request.getParameter("monthsAgo");
				int monthsAgo = 12;
				try {
					if (monthsAgoS != null) {
						monthsAgo = Integer.parseInt(monthsAgoS);
					}
				}
				catch (NumberFormatException nfe) {
					nfe.printStackTrace();
				}
				doGetAllComments(blogid, monthsAgo, request, response);
			} else if (action.endsWith("addspammertodatabase")) {
				String email = request.getParameter("email");
				String uri = request.getParameter("uri");
				String name = request.getParameter("name");
				doUpdateDatabase(email, uri, name, request, response);
			} else if (action.endsWith("viewspamdatabase")) {
				doViewDatabase(false, request, response);
			} else if (action.endsWith("cleanspamdatabase")) {
				doViewDatabase(true, request, response);
			} else if (action.endsWith("configdatabase")) {
				String supportsSQLXMLS = request.getParameter("supportsSQLXML");
				String justView = request.getParameter("justView");
				boolean supportsSQLXML = Boolean.parseBoolean(supportsSQLXMLS);
				doConfigDatabase(justView != null, supportsSQLXML, request, response);
			}
			else {
				throw new ServletException("invalid action in post parameters");
			}
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	private void doGetAllBlogs(String profileId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		XDynamicContext dc = factory.newDynamicContext();
		
		dc.bind(Constants.PROFILE_ID_QNAME, profileId);
		
		StreamSource input = new StreamSource(Constants.getInputStream(true, profileId));
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());
		
		XSequenceCursor seq = getAllBlogs.execute(input, dc);
		seq.exportSequence(output, outParms);
	}
	
	private void doGetAllComments(String blogId, int monthsAgo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		XDynamicContext dc = factory.newDynamicContext();
		
		dc.bind(Constants.VULGAR_NAMES_QNAME, Constants.VULGAR_WORDS);

		// Bind a XML Duration for the number of months specified
		Duration dMonthsAgo = DatatypeFactory.newInstance().newDurationYearMonth(true, 0, monthsAgo);
		dc.bind(Constants.MONTHS_AGO_QNAME, dMonthsAgo);
		
		dc.bindFunction(Constants.LEGACY_CONTENT_ANALYSIS_QNAME, ExtensionFunctions.class.getMethod("legacyContentAnalysis", String.class));
		
		StreamSource input = new StreamSource(Constants.getInputStream(false, blogId));
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());

		Connection conn = null;
		boolean databaseAvailable = true;
		try {
			conn = getConnection();
		}
		catch (Exception e) {
			databaseAvailable = false;
		}
		dc.bind(Constants.DATABASE_AVAILABLE_QNAME, databaseAvailable);
		
		JDBCCollectionResolver inputResolver = new JDBCCollectionResolver(conn, Constants.dbStatements);
		inputResolver.setTreatClobAsXML(true);
		dc.setCollectionResolver(inputResolver);

		XSequenceCursor seq = getAllComments.execute(input, dc);
		seq.exportSequence(output, outParms);
		
		if (databaseAvailable) {
			conn.commit();
			conn.close();
		}
	}

	private void doUpdateDatabase(String email, String uri, String name, HttpServletRequest request, HttpServletResponse response) throws Exception {
		XDynamicContext dc = factory.newDynamicContext();
		
		dc.bind(Constants.USEREMAIL_QNAME, email);
		dc.bind(Constants.USERNAME_QNAME, name);
		dc.bind(Constants.USERURI_QNAME, uri);
		
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());
		
		
		Connection conn = null;
		try {
			conn = getConnection();
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
		
		JDBCCollectionResolver inputResolver = new JDBCCollectionResolver(conn, Constants.dbStatements);
		inputResolver.setTreatClobAsXML(true);
		
		dc.setCollectionResolver(inputResolver);
		dc.setXSLTInitialTemplate(new QName("main"));

		JDBCResultsResolver outputResolver = new JDBCResultsResolver(conn, Constants.dbStatements);
		outputResolver.setTreatClobAsXML(true);
		
		dc.setResultResolver(outputResolver);

		updateDatabaseWeb.execute(dc, output);
		outputResolver.executeUpdates();
		conn.commit();
		conn.close();
	}
	
	private void doViewDatabase(boolean deleteFirst, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Connection conn = null;
		boolean databaseAvailable = true;
		try {
			conn = getConnection();
		}
		catch (Exception e) {
			databaseAvailable = false;
		}
        
		if (databaseAvailable && deleteFirst) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM SPAMMERS");
            ps.executeUpdate();
            conn.commit();
        }
        
		XDynamicContext dc = factory.newDynamicContext();
		dc.bind(Constants.DATABASE_AVAILABLE_QNAME, databaseAvailable);
		dc.bind(Constants.TREAT_CLOB_AS_XML_QNAME, Constants.isTreatClobAsXML());
		dc.bind(Constants.DATABASE_CONFIG_QNAME, false);
		if (databaseAvailable) {
			JDBCCollectionResolver inputResolver = new JDBCCollectionResolver(conn, Constants.dbStatements);
			dc.setCollectionResolver(inputResolver);
			inputResolver.setTreatClobAsXML(true);
		}
		
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());

		dc.setXSLTInitialTemplate(new QName("main"));
		viewDatabase.execute(dc, output);
		if (databaseAvailable) {
			conn.commit();
			conn.close();
		}
	}
	
	private void doConfigDatabase(boolean justView, boolean supportsSQLXML, HttpServletRequest request, HttpServletResponse response) throws Exception {
		XDynamicContext dc = factory.newDynamicContext();
		if (!justView) {
			Constants.setTreatClobAsXML(!supportsSQLXML);
		}
		dc.bind(Constants.TREAT_CLOB_AS_XML_QNAME, Constants.isTreatClobAsXML());
		dc.bind(Constants.DATABASE_CONFIG_QNAME, true);
		
		Constants.setContentTypeBasedOnAccept(request, response);
		StreamResult output = new StreamResult(response.getOutputStream());

		dc.setXSLTInitialTemplate(new QName("main"));
		viewDatabase.execute(dc, output);
	}
	
	private Connection getConnection() throws Exception {
        Connection conn = datasource.getConnection();
        conn.setAutoCommit(false);
        return conn;
	}
}
