#!/bin/sh
# COPYRIGHT LICENSE: 
# This information contains sample code provided in source code form. You may 
# copy, modify, and distribute these sample programs in any form without 
# payment to IBM for the purposes of developing, using, marketing or 
# distributing application programs conforming to the application programming
# interface for the operating platform for which the sample code is written. 
# Notwithstanding anything to the contrary, IBM PROVIDES THE SAMPLE SOURCE CODE
# ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, 
# INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF 
# MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, 
# TITLE, AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT. IBM SHALL NOT BE 
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
# ARISING OUT OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE. IBM HAS NO 
# OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR 
# MODIFICATIONS TO THE SAMPLE SOURCE CODE.

# check WAS_HOME environment variable
USAGE_WAS_HOME="\nPlease run setupCmdLine.sh in the AppServer profile before running this batch file. For example: '. <WAS_HOME>/profiles/AppSrv01/bin/setupCmdLine.sh'\n"
if [ -z "$WAS_HOME"  ] ||
   [ ! -d $WAS_HOME  ] ||
   [ -z "$JAVA_HOME" ] 
then
   echo ""
   echo $USAGE_WAS_HOME
   echo ""
   exit 1
fi

cd `dirname $0`
SCRIPTS_DIR=$PWD
SAMPLES_HOME=$SCRIPTS_DIR/../..
cd $SAMPLES_HOME/installableApps

SAMPLE_HOST=localhost
SAMPLE_PORT=9080
SAMPLE_SYMBOL=XXX

if [ "$1" != "" ]; then
   SAMPLE_HOST=$1
   shift
fi

if [ "$1" != "" ]; then
   SAMPLE_PORT=$1
   shift
fi

if [ "$1" != "" ]; then
   SAMPLE_SYMBOL=$1
   shift
fi

$JAVA_HOME/bin/java $WAS_LOGGING -classpath "$WAS_CLASSPATH:$SAMPLES_HOME/installableApps/simpleClients.jar:$WAS_HOME/runtimes/com.ibm.ws.webservices.thinclient_8.0.0.jar" samples.stock.GetQuote http://$SAMPLE_HOST:$SAMPLE_PORT/StockQuote/services/xmltoday-delayed-quotes $SAMPLE_SYMBOL 

exit 0
