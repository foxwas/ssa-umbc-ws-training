/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

//
// "This program may be used, executed, copied, modified and distributed without 
// royalty for the purpose of developing, using, marketing, or distributing."
//
package samples.stock;

//  Use JAX-RPC
import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.NamespaceConstants;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceFactory;
import javax.xml.rpc.encoding.XMLType;

import java.net.URL;


/**
 * The <code>samples.stock.GetQuote</code> client utilizes
 * the dynamic invocation interface to invoke the StockQuote
 * service, using JAX-RPC.  This client was migrated from
 * the SOAP client.  Comments are included in the source
 * that indicate the changes made to migrate the client.
 *
 * @version 1.0
 */
public class GetQuote {
    public static void main (String[] args) throws Exception {
        if (args.length != 2
            && (args.length != 3 || !args[0].startsWith ("-"))) {
            System.err.println ("Usage: java " + GetQuote.class.getName () +
                                " [-encodingStyleURI] targetEndpointURL symbol");
            System.exit (1);
        }

        // Process the arguments.
        int offset = 3 - args.length;

        /**
         * Use a javax.xml.rpc.Call constant for the encoding style default string.
         */
        String encodingStyleURI = args.length == 3 ? args[0].substring(1) : "";

        /**
         * A string is needed by setTargetEndpointAddress, not a URL.
         */
        // Remove any "-l" flag that preceedes the target address.  The Axis
        // stock quote sample requires a "-l" so users familiar with that sample may
        // be accustomed to using the flag, so don't break if they specifed it.
        String url = new String (args[1 - offset]);
        if (url.startsWith("-l")) {
            url = url.substring(2);
        }

        String symbol = args[2 - offset];

        /**
         * Obtain a generic Service to create the Call.
         */
        javax.xml.rpc.Service service = ServiceFactory.newInstance().createService(new QName(""));

        // Build the call.
        Call call = service.createCall();

        /**
         * setTargetEndpointAddress takes the place of SOAP's setTargetObjectURI
         */
        call.setTargetEndpointAddress( url );

        /**
         * setOperationName takes the place of setMethodName
         */
        call.setOperationName( new QName("xmltoday-delayed-quotes", "getQuote") );

        /**
         * set encodingStyleURI property takes the place of setEncodingStyleURI
         */
        if ( encodingStyleURI != "" )
            call.setProperty( javax.xml.rpc.Call.ENCODINGSTYLE_URI_PROPERTY, encodingStyleURI );

        /**
         * Setting the operation style to wrapped since the wsdl is using wrapped/lit
         */
        call.setProperty( javax.xml.rpc.Call.OPERATION_STYLE_PROPERTY, "wrapped");

        /**
         * SOAP's setParams is replaced by addParameter.  It specifies a parameter's
         * characteristics, but not its value.
         */
        call.addParameter( "symbol", XMLType.XSD_STRING, ParameterMode.IN );

        /**
         * setReturnType is required
         */
        call.setReturnType( XMLType.XSD_FLOAT );

        try {
            /**
             * Unlike SOAP's invoke, JAX-RPC's does not return an RPCMessage.
             * Also, the parameter values are passed on the invoke, not on
             * addParameter.
             */
            Object objectReturn = call.invoke( new Object[] {symbol} );
            Float floatReturn = new Float(0.0F);
            floatReturn = (Float) objectReturn;
            Float _zero = new Float(0.0F);
            Float _negativeOne = new Float (-1.0F);
            Float _negativeTwo = new Float (-2.0F);
            Float _negativeThree = new Float (-3.0F);

            if (floatReturn.compareTo(_zero) == 0) {
                System.out.println("Price is being " + _zero + " for ticker " + symbol + 
                                   ". Please make sure ticker symbol, " + symbol + ", is valid.");
            } else if (floatReturn.compareTo(_zero) < 0) {
                if (floatReturn.compareTo(_negativeOne) == 0) {
                    System.out.println("Service receives an unexpected number format error from its provider.");
                } else if (floatReturn.compareTo(_negativeTwo) == 0) {
                    System.out.println("Service is unable read information from internet.");
                } else if (floatReturn.compareTo(_negativeThree) == 0) {
                    System.out.println("Services has encounter a problem.");
                } else {
                    System.out.println("There is an unknown error occured on the service side.");
                }
            } else {
                System.out.println(symbol + ": " + objectReturn);
            }
        } catch ( JAXRPCException jaxEx ) {
            /**
             * JAX-RPC's invoke throws a JAXRPCException if there is anything
             * wrong with configuration of the Call.
             */
            System.out.println ("The call failed: Call object, parms or return type incorrect");
            jaxEx.printStackTrace();
        } catch ( java.rmi.RemoteException rmiEx ) {
            /**
             * JAX-RPC's invoke throws a RemoteException if anything goes wrong
             * with the remote invocation.
             */
            System.out.println ("The call failed: Error in remote method invocation");
            rmiEx.printStackTrace();
        } catch ( Exception e ) {
            System.out.println ("Ouch, the call failed: ");
            e.printStackTrace();
        }

        // Need to do an exit so that any AWT resources that were created are closed.
        // These AWT resources include security popups.
        System.exit (0);
    }
}

//
// The original SOAP sample is included here for comparison.
//
//
// package samples.stockquote;
// 
// import java.io.*;
// import java.net.*;
// import java.util.*;
// import org.apache.soap.*;
// import org.apache.soap.rpc.*;
// 
// public class GetQuote {
//   public static void main (String[] args) throws Exception {
//     if (args.length != 2
//         && (args.length != 3 || !args[0].startsWith ("-"))) {
//       System.err.println ("Usage: java " + GetQuote.class.getName () +
//                           " [-encodingStyleURI] SOAP-router-URL symbol");
//       System.exit (1);
//     }
// 
//     // Process the arguments.
//     int offset = 3 - args.length;
//     String encodingStyleURI = args.length == 3
//                               ? args[0].substring(1)
//                               : Constants.NS_URI_SOAP_ENC;
//     URL url = new URL (args[1 - offset]);
//     String symbol = args[2 - offset];
// 
//     // Build the call.
//     Call call = new Call ();
//     call.setTargetObjectURI ("urn:xmltoday-delayed-quotes");
//     call.setMethodName ("getQuote");
//     call.setEncodingStyleURI(encodingStyleURI);
//     Vector params = new Vector ();
//     params.addElement (new Parameter("symbol", String.class, symbol, null));
//     call.setParams (params);
// 
//     // make the call: note that the action URI is empty because the
//     // XML-SOAP rpc router does not need this. This may change in the
//     // future.
//     Response resp = call.invoke (/* router URL */ url, /* actionURI */ "" );
// 
//     // Check the response.
//     if (resp.generatedFault ()) {
//       Fault fault = resp.getFault ();
//       System.out.println ("Ouch, the call failed: ");
//       System.out.println ("  Fault Code   = " + fault.getFaultCode ());
//       System.out.println ("  Fault String = " + fault.getFaultString ());
//     } else {
//       Parameter result = resp.getReturnValue ();
//       System.out.println (result.getValue ());
//     }
//   }
// }
