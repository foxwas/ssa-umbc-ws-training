/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

//
// "This program may be used, executed, copied, modified and distributed without 
// royalty for the purpose of developing, using, marketing, or distributing."
//
package com.ibm.websphere.samples.webservices.addr;

import java.net.URL;

import com.ibm.websphere.samples.webservices.addr.Address;
import com.ibm.websphere.samples.webservices.addr.Phone;
import com.ibm.websphere.samples.webservices.addr.AddressBook;
import com.ibm.websphere.samples.webservices.addr.AddressBookService;

/* JNDI */
import javax.naming.InitialContext;

/* ServiceFactory */
import javax.xml.rpc.ServiceFactory;
import javax.xml.namespace.QName;
import javax.xml.rpc.Service;



/**
 * Web Services J2EE client for AddressBook.
 */
public class AddressBookClient {

    /**
     * A flag to determine how to get the port.  If true, use JNDI 
     * lookup to get a Service.
     * To use a ServiceFactory to obtain a Service, set useJNDI false.
     * If useJNDI is true, the client must be run in a J2EE client container.
     */
    protected static final boolean useJNDI = true;

    /**
     * Port identifiers for the ports available on the AddressBookService.  This is
     * a four letter string such as "W2JE", indicating the port.
     */
    protected static String[] portVers = {"W2JE", "J2WE", "J2WB", "W2JB"};

    /**
     * The property name for setting an end point on a port.
     */
    static final String endPointProperty = "javax.xml.rpc.service.endpoint.address";

    static String name = "Purdue Boilermaker";

    /**
     * Print the contents of an Address object
     *
     * @param anAddress - the Address to print
     */ 
    protected static void printAddress (Address anAddress) {
        if (anAddress == null) {
            System.err.println ("\t[Address not found]");
            return;
        }
        System.err.println ("\t" + anAddress.getStreetNum() + " " + anAddress.getStreetName());
        System.err.println ("\t" + anAddress.getCity() + ", " + 
                            anAddress.getState() + " " + anAddress.getZip());
        Phone aPhone = anAddress.getPhoneNumber();
        System.err.println ("\tPhone: (" + aPhone.getAreaCode() + ") " + 
                            aPhone.getExchange() + "-" + aPhone.getNumber());
    }

    /**
     * Get a port or interface using a Service obtained from a ServiceFactory.  A generic 
     * AddressBookService is obtained from the factory.  The port is obtained
     * by calling getPort with a port QName and the class on the Service.
     *
     * @param portVer - the port identifier 
     * @return an object implementing AddressBook 
     * @exception javax.xml.rpc.ServiceException if accessing the service or
     *                  port fails.
     * @exception java.net.MalformedURLException if an invalid URL is obtained.
     */
    protected static AddressBook getPortFromFactory( String portVer )
    throws javax.xml.rpc.ServiceException, java.net.MalformedURLException
    {
        Service abService = ServiceFactory.newInstance().createService(
                                                                      new URL("file", "", "AddressBook.wsdl"),
                                                                      new QName("http://addr.webservices.samples.websphere.ibm.com", "AddressBookService"));

        return(AddressBook) abService.getPort(
                                             new QName("http://addr.webservices.samples.websphere.ibm.com", "AddressBook" + portVer),
                                             AddressBook.class);
    }


    /**
     * Get a port or interface using a Service obtained from a JNDI lookup.  A generic
     * AddressBookService is obtained from JNDI.  A particular port is obtained from it
     * by calling get*port*, where *port* is particular port name, like
     * "AddressBookJ2EB".  A JNDI lookup will work only if the client is 
     * running in a J2EE client container.
     *
     * @param portVer - the port identifier 
     * @return an object implementing AddressBook 
     * @exception javax.xml.rpc.ServiceException if accessing the service or
     *                  port fails.
     * @exception javax.naming.NamingException if the JNDI lookup fails.
     */
    protected static AddressBook getPortFromJNDI( String portVer ) 
    throws javax.xml.rpc.ServiceException, javax.naming.NamingException,
    java.lang.NoSuchMethodException, java.lang.IllegalAccessException,
    java.lang.reflect.InvocationTargetException
    {
        AddressBook ab = null;
        java.util.Properties prop = new java.util.Properties();
        InitialContext ctx = new InitialContext(prop);
        AddressBookService abService = 
        (AddressBookService) ctx.lookup("java:comp/env/service/AddressBookService");

        // 
        // Form a QName with a unique localpart, like "AddressBookW2JE".  
        // Call generic getPort with QName and class to get an AddressBook.
        // 
        QName portQName = new QName("http://addr.webservices.samples.websphere.ibm.com",
                                    "AddressBook" + portVer);
        ab = (AddressBook) abService.getPort( portQName, AddressBook.class);

        return(AddressBook) ab;
    }

    public static void main (String[] args) throws Exception {

        if (args.length != 0 && args.length != 2) {
            System.err.println("Usage: AddressBookClient [<targetEndpointHostName> <targetEndpointPortNumber>]");
            System.exit(1);
        }

        AddressBook ab;

        try {
            if (useJNDI) {
                for (int i = 0; i < portVers.length; i++) {
                    System.err.println (">> Querying address for '" + name + 
                                        "' using port " + "AddressBook" + portVers[i]);
                    ab = getPortFromJNDI( portVers[i] );
                    if (args.length == 2) {
                        String endPoint = new String("http://" + args[0] + ":" + args[1] + "/AddressBook" + portVers[i] + "/services/AddressBook");
                        ((javax.xml.rpc.Stub) ab)._setProperty(endPointProperty, endPoint);
                    }
                    Address resp = ab.getAddressFromName (name);
                    System.err.println (">> Response is:");
                    printAddress (resp);
                }
            } else {
                for (int i = 0; i < portVers.length; i++) {
                    ab = getPortFromFactory( portVers[i] );
                    System.err.println (">> Querying address for '" + name +
                                        "' using port " + "AddressBook" + portVers[i]);
                    if (args.length == 2) {
                        String endPoint = new String("http://" + args[0] + ":" + args[1] + "/AddressBook" + portVers[i] + "/services/AddressBook");
                        ((javax.xml.rpc.Stub) ab)._setProperty(endPointProperty, endPoint);
                    }
                    Address resp = ab.getAddressFromName (name);
                    System.err.println (">> Response is:");
                    printAddress (resp);
                }

                //
                // Demonstrate getting one port, then changing it's endpoint to others.
                //
                System.err.println (">>"); 
                ab = getPortFromFactory( portVers[2] );
                System.err.println (">> Get port AddressBook" + portVers[2] );

                // Default target endpoint host and port
                String host = "localhost";
                String port = "9080";

                if (args.length == 2) {
                    // Override the default target endpoint host and port
                    host = args[0];
                    port = args[1];     
                }

                for (int i = 0; i < portVers.length; i++) {

                    String endPoint = new String("http://" + host + ":" + port + "/AddressBook" +
                                                 portVers[i] + "/services/AddressBook");
                    ((javax.xml.rpc.Stub) ab)._setProperty(endPointProperty, endPoint);
                    System.err.println (">> Set port AddressBook" + portVers[2] +
                                        "'s endpoint to " + endPoint );
                    System.err.println (">> Querying address for '" + name + "'");
                    Address resp = ab.getAddressFromName (name);
                    System.err.println (">> Response is:");
                    printAddress (resp);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
}

