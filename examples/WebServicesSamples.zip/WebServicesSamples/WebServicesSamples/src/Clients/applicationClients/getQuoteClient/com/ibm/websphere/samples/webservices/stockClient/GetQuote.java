/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

//
// "This program may be used, executed, copied, modified and distributed without 
// royalty for the purpose of developing, using, marketing, or distributing."
//
package com.ibm.websphere.samples.webservices.stockClient;

import javax.naming.InitialContext;

/**
 *
 * @author Doug Davis (dug@us.ibm.com)
 */
public class GetQuote {
    public  String symbol;


    /**
     * The property name for setting an end point on a port.
     */
    static final String endPointProperty = "javax.xml.rpc.service.endpoint.address";

    // helper function - does all the real work
    public float getQuote (String args[]) throws Exception {


        float res = 0;

        if ( ( args.length < 1 ) || ( args.length > 2 ) ) {
            System.err.println( "Usage: GetQuote [ targetEndpointURL] <symbol>" );
            System.exit(1);
        }

        symbol = args[ args.length - 1 ];

        // Locate a Service Object (However you can)
        java.util.Properties prop = new java.util.Properties();
        InitialContext ctx = new InitialContext(prop);

        StockQuoteService service = (StockQuoteService) 
                                    ctx.lookup("java:comp/env/service/StockQuoteService");

        // Request the Port Object from it
        StockQuote portType = service.getStockQuote();


        if (args.length == 2) {
            // Remove any "-l" flag that preceedes the target address.  The Axis
            // stock quote sample requires a "-l" so users familiar with that sample may
            // be accustomed to using the flag, so don't break if they specifed it.
            //
            String endPoint = new String (args[0]);
            if (endPoint.startsWith("-l")) {
                endPoint = endPoint.substring(2);
            }
            ((javax.xml.rpc.Stub) portType)._setProperty(endPointProperty, endPoint);
        }


        // Get the quote
        res = portType.getQuote( symbol );

        return res;
    }


    public static void main(String args[]) {
        try {
            GetQuote gq = new GetQuote();
            float val = gq.getQuote(args);
            // args array gets side-effected
            Float objectReturn = new Float(val);
            Float floatReturn = new Float(0.0F);
            floatReturn = objectReturn;

            Float _zero = new Float(0.0F);
            Float _negativeOne = new Float (-1.0F);
            Float _negativeTwo = new Float (-2.0F);
            Float _negativeThree = new Float (-3.0F);

            if (floatReturn.compareTo(_zero) == 0) {
                System.out.println("Price is  " + _zero + " for ticker " + gq.symbol + 
                                   ". Please make sure ticker symbol, " + gq.symbol + ", is valid.");
            } else if (floatReturn.compareTo(_zero) < 0) {
                if (floatReturn.compareTo(_negativeOne) == 0) {
                    System.out.println("Service receives an unexpected number format error from its provider.");
                } else if (floatReturn.compareTo(_negativeTwo) == 0) {
                    System.out.println("Service is unable read information from internet.");
                } else if (floatReturn.compareTo(_negativeThree) == 0) {
                    System.out.println("Services has encounter a problem.");
                } else {
                    System.out.println("There is an unknown error occured on the service side.");
                }
            } else {
                System.out.println(gq.symbol + ": " + val);
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    public GetQuote () {
    };

};
