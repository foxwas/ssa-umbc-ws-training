/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Axis" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

//
// "This program may be used, executed, copied, modified and distributed without 
// royalty for the purpose of developing, using, marketing, or distributing."
//
package com.ibm.websphere.samples.webservices.stock;

import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.*;

import java.io.*;
import java.util.* ;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;

import org.w3c.dom.* ;
import javax.xml.parsers.*;

/**
 * This is a Session Bean Class
 */
public class StockQuoteBean implements SessionBean {
    private javax.ejb.SessionContext mySessionCtx = null;
    private final static long serialVersionUID = 3206093459760846163L;

/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
    public void ejbActivate() throws java.rmi.RemoteException {}
/**
 * ejbCreate method comment
 * @exception javax.ejb.CreateException The exception description.
 */
    public void ejbCreate() throws javax.ejb.CreateException {}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
    public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 */
    public void ejbRemove() throws java.rmi.RemoteException {}


/**
 * Insert the method's description here.
 * Creation date: (02/03/2005 1:00:39 PM)
 * @return float
 * @param symbol java.lang.String
 */

    public float getQuote(String symbol)  {
        URL url = null;
        URLConnection urlConn = null;
        InputStreamReader isr = null;
        BufferedReader buff = null;
        StringTokenizer tokenizer = null;

        String inString = null;
        String ticker = null;
        String quoteStr = null;



        if ( symbol.equals("XXX") ) return( (float) 55.25 );

        try {

            try {
                // Get a real (delayed by 20min) stockquote.
                //                     
                // 
                // Due to the unavailability of the stock quote service from URL:                    
                // "http://services.xmethods.net/axis/getQuote?s="+symbol 
                // The new provider URL:
                // "http://quote.yahoo.com/d/quotes.csv?s=" + symbol + "&f=sl1d1t1c1ohgv&e=.csv"
                // is used since Feburary 2005. 
                //
                // A newer provider URL:
                // "http://download.finance.yahoo.com/d/quotes.csv?s=" + symbol + "&f=sl1d1t1c1ohgv"
                // Since 02/01/2011
                // 
                // NOTE: Throughout the rest of the sample, the identifiers using 
                // "xmltoday-delayed-quotes" are arbitrary names local to this sample.
                // 
                url  = new URL("http://download.finance.yahoo.com/d/quotes.csv?s=" + symbol + "&f=sl1d1t1c1ohgv" );
                urlConn = url.openConnection();
                isr = new  InputStreamReader(urlConn.getInputStream());
                buff= new BufferedReader(isr);

                // get the quote as a string
                inString = buff.readLine(); 

                // close input stream
                try {
                    isr.close();
                    buff.close();   
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // parse the quote string
                tokenizer = new StringTokenizer(inString, ",");
                ticker = tokenizer.nextToken();
                quoteStr  = tokenizer.nextToken();

                try {
                    return Float.valueOf(quoteStr).floatValue();
                } catch (NumberFormatException e1) {
                    // maybe it is an integer?
                    try {
                        return Integer.valueOf(quoteStr).intValue() * 1.0F;
                    } catch (NumberFormatException e2) {
                        return -1.0F; 
                    }
                }

            } catch (IOException  e1) {
                System.out.println("Input/output error occurs: " + 
                                   e1.toString() ); 
                return -2.0F;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -3.0F;
        }

    }



/**
 * This is the old version of getQuote method included here for comparison.
 * Creation date: (10/17/2001 1:00:39 PM)
 * @return float
 * @param symbol java.lang.String
 */
//      public float getQuote(String symbol)  {
//
//              if ( symbol.equals("XXX") )     return( (float) 55.25 );
//
//              try {
//                  // Get a real (delayed by 20min) stockquote.
//                  // 
//                  // The stock quote service website changed November 2002. The old URL was:
//                  // "http://www.xmltoday.com/examples/stockquote/getxmlquote.vep?s="+symbol
//                  // 
//                  // NOTE: Throughout the rest of the sample, the identifiers using 
//                  // "xmltoday-delayed-quotes" are arbitrary names local to this sample.
//                  // 
//                    URL url = new URL( "http://services.xmethods.net/axis/getQuote?s="+symbol );
//                      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//                      DocumentBuilder        db  = dbf.newDocumentBuilder();
//
//                      Document doc  = db.parse( url.toExternalForm() );
//                      Element  elem = doc.getDocumentElement();
//                      NodeList list = elem.getElementsByTagName( "stock_quote" );
//
//                      if ( list != null && list.getLength() != 0 ) {
//                              elem = (Element) list.item(0);
//                              list = elem.getElementsByTagName( "price" );
//                              elem = (Element) list.item(0);
//                              String quoteStr = elem.getAttribute("value");
//                              try {
//                                      return Float.valueOf(quoteStr).floatValue();
//                              } catch (NumberFormatException e1) {
//                                      // maybe its an int?
//                                      try {
//                                              return Integer.valueOf(quoteStr).intValue() * 1.0F;
//                                      } catch (NumberFormatException e2) {
//                                              return -1.0F; 
//                                      }
//                              }
//                      }
//              } catch (Exception e) {
//                  e.printStackTrace();
//                  return -1.0F;
//              }
//              return( 0 );
//      }

/**
 * getSessionContext method comment
 * @return javax.ejb.SessionContext
 */
    public javax.ejb.SessionContext getSessionContext() {
        return mySessionCtx;
    }
/**
 * setSessionContext method comment
 * @param ctx javax.ejb.SessionContext
 * @exception java.rmi.RemoteException The exception description.
 */
    public void setSessionContext(javax.ejb.SessionContext ctx) throws java.rmi.RemoteException {
        mySessionCtx = ctx;
    }
}
