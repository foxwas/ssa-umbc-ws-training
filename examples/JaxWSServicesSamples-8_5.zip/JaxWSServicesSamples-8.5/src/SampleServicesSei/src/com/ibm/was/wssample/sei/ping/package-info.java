@javax.xml.bind.annotation.XmlSchema(namespace = "http://com/ibm/was/wssample/sei/ping/")
package com.ibm.was.wssample.sei.ping;
